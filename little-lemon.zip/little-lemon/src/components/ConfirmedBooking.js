import React from "react";

const ConfirmedBooking = () => {
    return(
        <header>
            <section>
            <h1>Booking has been confirmed!
        </h1>
            </section>
        </header>

    )
}

export default ConfirmedBooking;